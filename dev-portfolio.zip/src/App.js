import React from 'react'
import { useTranslation } from 'react-i18next'
import { Analytics } from '@vercel/analytics/react';
import './App.css'

import Home from './components/home/Home'
import About from './components/about/About'
import Skills from './components/skills/Skills'
import Experience from './components/experience/Experience'
import Projects from './components/projects/Projects'
import Contact from './components/contact/Contact'
import Footer from './components/footer/Footer'
import TopButton from './components/topButton/TopButton'

function App() {
  const { i18n } = useTranslation()

  return (
    <div className="App">
      <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end', margin: '1rem' }}>
        <button
          onClick={() => i18n.changeLanguage('es')}
          style={{ fontWeight: i18n.language === 'es' ? 'bold' : 'normal' }}
        >🇪🇸 Español</button>
        <button
          onClick={() => i18n.changeLanguage('en')}
          style={{ fontWeight: i18n.language === 'en' ? 'bold' : 'normal' }}
        >🇺🇸 English</button>
      </div>
      <Analytics />
      <Home />
      <About />
      <Skills />
      <Experience />
      <Projects />
      <Contact />
      <Footer />
      <TopButton />
    </div>
  )
}

export default App
